package com.example.itegy;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.FrameLayout;
import android.widget.SearchView;

import com.example.itegy.Fragments.AccountFragment;
import com.example.itegy.Fragments.CategoriesFragment;
import com.example.itegy.Fragments.FavoriteFragment;
import com.example.itegy.Fragments.HomeFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class HomeActivity extends AppCompatActivity {

    SearchView searchView;
    FrameLayout framelayout ;
    BottomNavigationView bottomNavigation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);


        /////////////////////////////////// frame layout /////////////////////////////////////////
        framelayout =(FrameLayout) findViewById(R.id.framelayout);


        ////////////////////////////////////////////////////////// bottom navigation///////////////////////////////
        bottomNavigation = (BottomNavigationView) findViewById(R.id.bottomnavigation);
        bottomNavigation.setOnNavigationItemSelectedListener((BottomNavigationView.OnNavigationItemSelectedListener) bottomNavigation);
        BottomNavigationView.OnNavigationItemSelectedListener navigation = new BottomNavigationView.OnNavigationItemSelectedListener() {



            @SuppressLint("ValidFragment")
            class CartFragment extends Fragment {
            }

            @SuppressLint("ValidFragment")
            class FavoriteFragment extends Fragment {
            }

            @SuppressLint("ValidFragment")
            class CategoriesFragment extends Fragment {
            }

            @SuppressLint("ValidFragment")
            class AccountFragment extends Fragment {
            }
            Fragment selectFragment = null ;

            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment selectFragment = null;
                switch (item.getItemId()) {
///*
                    case R.id.home:
                        selectFragment = new Fragment();
                        break;

                    case R.id.categories:
                        selectFragment = new CategoriesFragment();
                        break;
                    case R.id.account:
                        selectFragment = new AccountFragment();
                        break;

                    case R.id.favorite:
                        selectFragment = new FavoriteFragment();
                        break;

                    case R.id.cart:
                        selectFragment = new CartFragment();
                        break;
                    default:
                        throw new IllegalStateException("Unexpected value: " + item.getItemId());
                }
                ///////////////////////////////replacing fragments from home activity//////////////////////////////
                final int commit = getSupportFragmentManager().beginTransaction().replace(R.id.framelayout,
                        selectFragment).commit();
                       return true;
            }


        };
        searchView =(SearchView)findViewById(R.id.searchview);


    }


    }

